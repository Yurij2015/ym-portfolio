<script setup lang="ts">
const { locale, t } = useI18n()
const localePath = useLocalePath()
const { global } = useAppConfig()

const { data: services } = await useAsyncData(
  () => `services-${locale.value}`,
  () => queryCollection(`services_${locale.value}` as 'services_uk').order('order', 'ASC').all(),
  { watch: [locale] }
)

const serviceSlug = (service: { stem?: string }) =>
  String(service.stem ?? '').split('/').pop() ?? ''

const GROUPS = ['technology', 'modernization', 'build', 'engagement'] as const

const grouped = computed(() =>
  GROUPS
    .map(group => ({
      key: group,
      items: (services.value ?? []).filter(service => service.group === group)
    }))
    .filter(group => group.items.length)
)

const title = t('services.title')
const description = t('services.description')

useSeoMeta({
  title,
  ogTitle: title,
  description,
  ogDescription: description
})

defineOgImage('Portfolio', { title, description, headline: title }, { alt: title })

const origin = (useRuntimeConfig().public.siteUrl as string) || useRequestURL().origin

useHead({
  script: [{
    type: 'application/ld+json',
    key: 'services-ld',
    innerHTML: computed(() => JSON.stringify({
      '@context': 'https://schema.org',
      '@graph': [
        {
          '@type': 'ItemList',
          'name': title,
          'itemListElement': (services.value ?? []).map((service, index) => ({
            '@type': 'ListItem',
            'position': index + 1,
            'name': service.title,
            'url': `${origin}${localePath(`/services/${serviceSlug(service)}`)}`
          }))
        },
        {
          '@type': 'BreadcrumbList',
          'itemListElement': [
            { '@type': 'ListItem', 'position': 1, 'name': 'Home', 'item': `${origin}${localePath('/')}` },
            { '@type': 'ListItem', 'position': 2, 'name': title, 'item': `${origin}${localePath('/services')}` }
          ]
        }
      ]
    }))
  }]
})
</script>

<template>
  <UPage>
    <UPageSection :ui="{ container: 'pt-20! sm:pt-24!' }">
      <UPageHero
        :title="title"
        :description="description"
        :ui="{
          container: 'pt-0! pb-10 lg:pb-12',
          title: 'mx-0! text-left',
          description: 'mx-0! text-left'
        }"
      />

      <div
        v-for="group in grouped"
        :key="group.key"
        class="mb-10"
      >
        <h2 class="text-xl font-semibold text-highlighted mb-4">
          {{ t(`services.groups.${group.key}`) }}
        </h2>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <NuxtLink
            v-for="service in group.items"
            :key="serviceSlug(service)"
            :to="localePath(`/services/${serviceSlug(service)}`)"
            class="group flex flex-col rounded-xl border border-default bg-elevated/30 p-5 transition-colors hover:border-primary/50"
          >
            <span class="inline-flex items-center justify-center size-10 rounded-lg bg-elevated text-primary">
              <UIcon
                :name="service.icon"
                class="size-5"
              />
            </span>
            <h3 class="mt-4 font-semibold text-highlighted group-hover:text-primary transition-colors">
              {{ service.title }}
            </h3>
            <p class="mt-1 text-sm text-muted line-clamp-3 flex-1">
              {{ service.description }}
            </p>
            <p class="mt-4 text-sm font-medium text-default">
              {{ t(service.priceUnit === 'hour' ? 'services.priceFromHourly' : 'services.priceFrom', { price: service.priceFrom }) }}
            </p>
          </NuxtLink>
        </div>
      </div>

      <UPageCTA
        class="mt-6"
        :title="t('services.ctaIndexTitle')"
        :description="t('projectsCta.description')"
        :links="[
          { label: t('contact.telegram'), to: global.meetingLink, color: 'primary', icon: 'i-simple-icons-telegram', target: '_blank' },
          { label: t('contact.email'), to: `mailto:${global.email}`, color: 'neutral', icon: 'i-heroicons-envelope' }
        ]"
      />
    </UPageSection>
  </UPage>
</template>
